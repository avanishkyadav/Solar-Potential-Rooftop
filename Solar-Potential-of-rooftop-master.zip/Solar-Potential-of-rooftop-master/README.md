# Solar-Potential-of-rooftop
This project aims at making people aware about their roof’s solar potential by predicting the cost saved by them after installing the solar panel taking in consideration the irradiation on the surface and total area exposed to the surface over the year

This Project has been done by mapping 3 states of India currently namely Uttar Pradesh,Bihar and Jharkhand. We are aiming to expand it for all over the country.
